package acc.br;

import acc.br.model.Fruta;
import jakarta.transaction.Transactional;
import jakarta.ws.rs.*;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import org.jboss.logging.Logger;

import java.net.URI;
import java.util.List;

@Path("/frutas")
public class FrutasResource {
    private static final Logger LOG = Logger.getLogger(FrutasResource.class);

    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public List<Fruta> list() {
        LOG.info("Entrou no listar: ");
        return Fruta.listAll();
    }

    @POST
    @Transactional
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response novaFruta(Fruta frutaDTO) {
        LOG.info("Fruta: "+frutaDTO);
        frutaDTO.persist();
        return  Response.created(URI.create("/frutas" + frutaDTO.id)).entity(frutaDTO).build();
    }

    @DELETE
    @Path("/{id}")
    @Transactional
    public Response deletarFruta(@PathParam("id") Long id) {
        LOG.info("Id: "+id);
        Fruta fruta = Fruta.findById(id);
        if (fruta == null) {
            return Response.status(Response.Status.NOT_FOUND).build();
        }
        fruta.delete();
        return Response.ok().build();
    }

}
